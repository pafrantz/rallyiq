# RallyIQ — Deploy no GitHub Pages (para **pafrantz**)

Este README já vem **personalizado** para publicar o MVP PWA no GitHub Pages.

## URL final do site
**https://pafrantz.github.io/rallyiq/**

> O projeto já está configurado com `base: '/rallyiq/'` no `frontend/vite.config.ts` (feito).

---

## Passo a passo (no GitHub, via navegador)

1) Crie o repositório **rallyiq** na sua conta:  
   https://github.com/new —> *Repository name*: `rallyiq`

2) Envie todos os arquivos deste pacote para o repositório (arraste e solte ou via `git`).

3) Vá em **Settings → Pages** e, em **Build and deployment → Source**, selecione **GitHub Actions**.  
   - O workflow **Deploy to GitHub Pages** (`.github/workflows/pages-deploy.yml`) já está no repositório.  
   - O primeiro `push` na branch **main** dispara o deploy automático.

4) (Importante para o feed ao vivo) Vá em **Settings → Actions → General → Workflow permissions** e marque:  
   **Read and write permissions**.  
   - Isso permite que o workflow **Update live feed** (`.github/workflows/live-cron.yml`) faça `git push` no `live.json`.

5) Confira a aba **Actions**:  
   - Deve aparecer o job **Deploy to GitHub Pages** concluído com sucesso.  
   - Em **Settings → Pages** aparecerá a URL: **https://pafrantz.github.io/rallyiq/**

6) Abra a URL no celular e use **“Adicionar à tela inicial”** (Android/Chrome ou iOS/Safari) para instalar como app (**PWA**).

---

## Dicas rápidas

- **Base do Vite**  
  Já está como `base: '/rallyiq/'` em `frontend/vite.config.ts`.  
  Se mudar o nome do repositório, ajuste essa linha para corresponder ao novo caminho.

- **Atualização do feed** (`live.json`)  
  A Action **Update live feed** roda **a cada minuto** e sobrescreve `frontend/public/live.json` com um novo “frame” simulado.  
  Se quiser desativar/ralentear, edite o cron em `.github/workflows/live-cron.yml`.

- **Testar localmente**  
  ```bash
  cd frontend
  npm install
  npm run dev
  ```

- **Erros comuns**  
  - **404 logo após o deploy**: aguarde 1–2 minutos; confira se `base: '/rallyiq/'` está correto e se a **Source** em Pages é **GitHub Actions**.  
  - **Cron não atualiza o live.json**: verifique **Workflow permissions** → **Read and write permissions**.

---

## Próximos passos (opcionais)
- Integrar um provedor de Push (ex.: Firebase Cloud Messaging) para alertas.  
- Substituir heurísticas por **modelo TF.js** exportado do seu treino.  
- Criar **rotas** por esporte (NFL, futebol, basquete, vôlei).

Bom deploy! 🚀
